package com.credera.training.cronjob.service;


public interface MasterVariantService {

    public void processMasterVariantFile();
}
