package com.credera.training.cronjob.service;

public interface PropertiesService {

    public void processPropertiesFile();
}
