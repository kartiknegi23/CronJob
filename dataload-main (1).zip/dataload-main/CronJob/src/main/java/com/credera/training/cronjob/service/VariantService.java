package com.credera.training.cronjob.service;

public interface VariantService {
	
	public void processVariantFile();
}
