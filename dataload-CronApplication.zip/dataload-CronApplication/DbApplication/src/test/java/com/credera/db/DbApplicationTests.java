package com.credera.db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbApplicationTests {

	@Test
	void contextLoads() {
	}

}
