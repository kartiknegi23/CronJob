package com.credera.training.cronjob.service;

public interface PriceService {
    public void processPriceFile();
}
