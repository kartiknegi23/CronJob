package com.credera.training.cronjob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsDay2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
